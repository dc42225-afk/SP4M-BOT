# Spam-Bot
A simple Spam-Bot written in Python with a user-friendly UI

After you pressed "Start", it is going to type the text automatically (after the configured delay) and press enter after the text has been written. That means that it will work with alsmost all chat-apps.

## Features:
- Write content automatically
- Choose how often your text message is written
- Choose a start delay
- Choose a delay beetween messages


## Download
### **[Version 1.0:](https://github.com/Pixel-Master/Spam-Bot/releases/tag/v1.0.0)**
#### Changelog:

- Realease

#### Downloads:

- [Windows](https://github.com/Pixel-Master/Spam-Bot/releases/download/v1.0.0/Spam-Bot.exe)
- [Mac](https://github.com/Pixel-Master/Spam-Bot/releases/download/v1.0.0/Spam-Bot.app.zip)
- [other Platforms](https://github.com/Pixel-Master/Spam-Bot#running-from-source)


## Running from Source 
### Dependencies (when running from source)
- [Python](https://python.org/) 3.6 or higher
- [Pyautogui](https://pyautogui.readthedocs.io/en/latest/) 

Install pyautogui with pip:

`pip3 install pyautogui`(MacOS and Linux) 

`pip install pyautogui`(Windows)

### Running
1. Install dependencies
2. Run:

`python3 Spam-Bot-mac.py`(MacOS and Linux) 

`python Spam-Bot-win.py`(Windows)
 
